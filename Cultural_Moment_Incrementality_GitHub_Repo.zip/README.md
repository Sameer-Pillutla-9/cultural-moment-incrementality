# Cultural-Moment Campaign Incrementality and Brand-Lift Measurement

> **Portfolio disclosure:** This project uses fully synthetic, de-identified data designed to demonstrate analytics methodology. It does not use Google, YouTube, advertiser, or user-level production data.

## Five-point project description

1. **Business problem:** Estimate whether exposure to a cultural-moment campaign incrementally reactivates lapsed viewers, beyond seasonality and baseline audience differences.
2. **Data model:** Create a reproducible user-period event table with pre/post outcomes, exposure, audience segment, baseline engagement, and a synthetic brand-lift survey.
3. **Causal design:** Apply Difference-in-Differences (DiD), inverse-propensity weighting (IPW), CUPED variance reduction, bootstrap confidence intervals, covariate balance checks, and a placebo test.
4. **Decision output:** Produce an effect table that separates an estimated direct incrementality signal from uncertainty, plus an executive-facing summary with brand-awareness and consideration outcomes.
5. **Responsible interpretation:** Document assumptions, data provenance, identification threats, and why the results are illustrative rather than evidence of real platform impact.

## Repository structure

```text
├── data/
│   └── generate_synthetic_data.py
├── sql/
│   └── 01_campaign_measurement_model.sql
├── src/
│   └── analyze_incrementality.py
├── tests/
│   └── test_incrementality.py
├── output/                 # Generated locally; ignored by Git
└── requirements.txt
```

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python data/generate_synthetic_data.py
python src/analyze_incrementality.py
pytest -q
```

## What to discuss in an interview

- Why raw post-campaign outcome differences are biased when exposure is not randomized.
- The DiD identification assumption: treated and control groups would have followed parallel outcome trends absent the campaign.
- Why IPW and balance diagnostics matter, and why they do not eliminate unobserved confounding.
- How CUPED can reduce variance using a pre-period covariate.
- How you would upgrade this design with a pre-registered randomized holdout, more pre-periods, and independently collected brand-lift survey data.

## Resume claim only after completion

Designed a quasi-experimental cultural-moment measurement study using Difference-in-Differences, propensity weighting, CUPED, and bootstrap confidence intervals to estimate incremental lapsed-viewer reactivation and synthetic brand-lift outcomes. Built a BigQuery-ready data model and an executive effect-summary artifact that separated estimated direct lift, uncertainty, and design limitations.
