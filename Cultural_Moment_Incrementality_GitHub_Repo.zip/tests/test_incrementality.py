from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(ROOT / "src"))
from analyze_incrementality import fit_propensity_weights, did_effect


def test_propensity_weights_are_positive():
    events = pd.DataFrame(
        {
            "user_id": [1, 1, 2, 2, 3, 3, 4, 4],
            "period": ["pre", "post"] * 4,
            "post": [0, 1] * 4,
            "exposed": [0, 0, 1, 1, 0, 0, 1, 1],
            "audience_segment": ["casual", "casual", "lapsed", "lapsed", "enthusiast", "enthusiast", "casual", "casual"],
            "region": ["US", "US", "US", "US", "India", "India", "India", "India"],
            "pre_engagement": [1.0, 1.0, 2.0, 2.0, 3.0, 3.0, 1.2, 1.2],
            "prior_brand_awareness": [0, 0, 1, 1, 0, 0, 1, 1],
            "reactivated": [0, 0, 0, 1, 0, 0, 0, 1],
        }
    )
    weighted = fit_propensity_weights(events)
    assert weighted["ipw"].gt(0).all()
    assert weighted["propensity"].between(0, 1).all()
