"""Estimate synthetic campaign incrementality using DiD, IPW, CUPED, and bootstrapping."""
from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "output"
RNG = np.random.default_rng(7)


def fit_propensity_weights(events: pd.DataFrame) -> pd.DataFrame:
    """Fit exposure propensity from pre-treatment covariates and return stabilized IPW."""
    user = (
        events.query("period == 'pre'")
        [["user_id", "exposed", "audience_segment", "region", "pre_engagement", "prior_brand_awareness"]]
        .drop_duplicates("user_id")
        .copy()
    )
    features = ["audience_segment", "region", "pre_engagement", "prior_brand_awareness"]
    preprocessor = ColumnTransformer(
        [
            ("categorical", OneHotEncoder(handle_unknown="ignore"), ["audience_segment", "region"]),
            ("numeric", StandardScaler(), ["pre_engagement", "prior_brand_awareness"]),
        ]
    )
    model = Pipeline(
        [("prep", preprocessor), ("logit", LogisticRegression(max_iter=1000, random_state=7))]
    )
    model.fit(user[features], user["exposed"])
    user["propensity"] = model.predict_proba(user[features])[:, 1]
    treatment_rate = user["exposed"].mean()
    user["ipw"] = np.where(
        user["exposed"].eq(1),
        treatment_rate / user["propensity"],
        (1 - treatment_rate) / (1 - user["propensity"]),
    )
    user["ipw"] = user["ipw"].clip(upper=user["ipw"].quantile(0.99))
    return events.merge(user[["user_id", "propensity", "ipw"]], on="user_id", how="left")


def standardized_mean_difference(frame: pd.DataFrame, column: str) -> float:
    treated = frame.loc[frame["exposed"].eq(1), column]
    control = frame.loc[frame["exposed"].eq(0), column]
    pooled_sd = np.sqrt((treated.var(ddof=1) + control.var(ddof=1)) / 2)
    return float((treated.mean() - control.mean()) / pooled_sd) if pooled_sd else 0.0


def did_effect(events: pd.DataFrame) -> tuple[float, float, float]:
    model = smf.wls(
        "reactivated ~ post * exposed + C(audience_segment) + C(region) + pre_engagement",
        data=events,
        weights=events["ipw"],
    ).fit(cov_type="HC3")
    coefficient = model.params["post:exposed"]
    ci_low, ci_high = model.conf_int().loc["post:exposed"].tolist()
    return float(coefficient), float(ci_low), float(ci_high)


def cuped_effect(events: pd.DataFrame) -> float:
    wide = events.pivot(index="user_id", columns="period", values="reactivated").reset_index()
    theta = np.cov(wide["post"], wide["pre"], ddof=1)[0, 1] / np.var(wide["pre"], ddof=1)
    wide["cuped_post"] = wide["post"] - theta * (wide["pre"] - wide["pre"].mean())
    exposed = events.query("period == 'post'")[["user_id", "exposed"]].drop_duplicates()
    wide = wide.merge(exposed, on="user_id", how="left")
    return float(wide.loc[wide.exposed.eq(1), "cuped_post"].mean() - wide.loc[wide.exposed.eq(0), "cuped_post"].mean())


def _weighted_did_from_panel(panel: pd.DataFrame) -> float:
    """Fast weighted DiD estimator on one row per user for bootstrap resampling."""
    treated = panel.loc[panel["exposed"].eq(1)]
    control = panel.loc[panel["exposed"].eq(0)]
    def wmean(frame: pd.DataFrame, col: str) -> float:
        return float(np.average(frame[col], weights=frame["ipw"]))
    return (wmean(treated, "post_outcome") - wmean(treated, "pre_outcome")) - (wmean(control, "post_outcome") - wmean(control, "pre_outcome"))


def bootstrap_did(events: pd.DataFrame, n_boot: int = 250) -> tuple[float, float]:
    """Bootstrap user panels, preserving each sampled user's pre/post records."""
    panel = (
        events.pivot_table(index=["user_id", "exposed", "ipw"], columns="period", values="reactivated", aggfunc="first")
        .reset_index()
        .rename(columns={"pre": "pre_outcome", "post": "post_outcome"})
    )
    panels = panel[["exposed", "ipw", "pre_outcome", "post_outcome"]].to_numpy()
    estimates = np.empty(n_boot)
    for i in range(n_boot):
        sampled = panel.iloc[RNG.integers(0, len(panel), len(panel))]
        estimates[i] = _weighted_did_from_panel(sampled)
    return float(np.quantile(estimates, 0.025)), float(np.quantile(estimates, 0.975))

def survey_lift(survey: pd.DataFrame, outcome: str) -> float:
    weighted = survey.groupby("exposed").apply(
        lambda x: np.average(x[outcome], weights=x["survey_weight"]), include_groups=False
    )
    return float(weighted.loc[1] - weighted.loc[0])


def main() -> None:
    OUTPUT_DIR.mkdir(exist_ok=True)
    events = pd.read_csv(DATA_DIR / "campaign_events.csv")
    survey = pd.read_csv(DATA_DIR / "brand_lift_survey.csv")
    events = fit_propensity_weights(events)

    effect, ci_low, ci_high = did_effect(events)
    boot_low, boot_high = bootstrap_did(events)
    cuped = cuped_effect(events)
    pre = events.query("period == 'pre'").copy()
    balance = {
        "pre_engagement_smd_before_weighting": standardized_mean_difference(pre, "pre_engagement"),
        "propensity_min": float(events["propensity"].min()),
        "propensity_max": float(events["propensity"].max()),
    }
    summary = pd.DataFrame(
        [
            {
                "metric": "IPW Difference-in-Differences reactivation effect",
                "estimate": effect,
                "robust_ci_low": ci_low,
                "robust_ci_high": ci_high,
                "bootstrap_ci_low": boot_low,
                "bootstrap_ci_high": boot_high,
            },
            {"metric": "CUPED-adjusted post-period exposure difference", "estimate": cuped},
            {"metric": "Weighted awareness lift", "estimate": survey_lift(survey, "brand_awareness")},
            {"metric": "Weighted consideration lift", "estimate": survey_lift(survey, "brand_consideration")},
        ]
    )
    summary.to_csv(OUTPUT_DIR / "effect_summary.csv", index=False)
    (OUTPUT_DIR / "diagnostics.json").write_text(json.dumps(balance, indent=2), encoding="utf-8")
    print(summary.to_string(index=False))
    print("\nDiagnostics:", json.dumps(balance, indent=2))


if __name__ == "__main__":
    main()
