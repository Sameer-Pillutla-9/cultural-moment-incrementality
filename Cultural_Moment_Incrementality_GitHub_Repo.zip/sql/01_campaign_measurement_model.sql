-- BigQuery Standard SQL. Replace project.dataset with your own dataset.
CREATE OR REPLACE TABLE `project.dataset.campaign_measurement_user_period` AS
SELECT
  user_id,
  period,
  post,
  exposed,
  audience_segment,
  region,
  pre_engagement,
  prior_brand_awareness,
  reactivated
FROM `project.dataset.raw_campaign_events`;

-- Pre-treatment feature mart for propensity modeling and CUPED covariates.
CREATE OR REPLACE TABLE `project.dataset.campaign_measurement_features` AS
SELECT
  user_id,
  ANY_VALUE(exposed) AS exposed,
  ANY_VALUE(audience_segment) AS audience_segment,
  ANY_VALUE(region) AS region,
  MAX(IF(period = 'pre', pre_engagement, NULL)) AS pre_engagement,
  MAX(IF(period = 'pre', reactivated, NULL)) AS pre_reactivated,
  MAX(IF(period = 'post', reactivated, NULL)) AS post_reactivated
FROM `project.dataset.campaign_measurement_user_period`
GROUP BY user_id;
