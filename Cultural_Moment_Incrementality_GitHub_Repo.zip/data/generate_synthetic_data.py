"""Generate synthetic campaign exposure, reactivation, and brand-lift data.

The generator deliberately creates treatment-selection bias. The analysis script
therefore has a reason to use propensity weighting instead of comparing raw means.
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def main(n_users: int = 8000) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    user_id = np.arange(1, n_users + 1)
    audience_segment = RNG.choice(
        ["casual", "lapsed", "enthusiast"], size=n_users, p=[0.48, 0.34, 0.18]
    )
    region = RNG.choice(["US", "India", "UK", "Brazil"], size=n_users, p=[0.42, 0.28, 0.14, 0.16])
    pre_engagement = RNG.gamma(shape=2.0, scale=1.25, size=n_users)
    prior_brand_awareness = RNG.binomial(1, sigmoid(-0.6 + 0.35 * pre_engagement))

    # Campaign exposure is intentionally non-random: enthusiastic, high-engagement users
    # are more likely to be reached. This creates confounding in the raw comparison.
    exposure_logit = (
        -1.15
        + 0.48 * pre_engagement
        + 0.52 * (audience_segment == "enthusiast")
        - 0.28 * (audience_segment == "lapsed")
        + 0.16 * (region == "US")
    )
    exposed = RNG.binomial(1, sigmoid(exposure_logit))

    rows: list[dict[str, object]] = []
    for period, post in [("pre", 0), ("post", 1)]:
        reactivation_logit = (
            -2.15
            + 0.34 * pre_engagement
            - 0.70 * (audience_segment == "lapsed")
            + 0.36 * (audience_segment == "enthusiast")
            + 0.18 * post
            + 0.68 * exposed * post  # true direct campaign lift in the simulation
            + 0.10 * (region == "India") * post
        )
        reactivated = RNG.binomial(1, sigmoid(reactivation_logit))
        for i in range(n_users):
            rows.append(
                {
                    "user_id": int(user_id[i]),
                    "period": period,
                    "post": post,
                    "exposed": int(exposed[i]),
                    "audience_segment": audience_segment[i],
                    "region": region[i],
                    "pre_engagement": round(float(pre_engagement[i]), 4),
                    "prior_brand_awareness": int(prior_brand_awareness[i]),
                    "reactivated": int(reactivated[i]),
                }
            )

    events = pd.DataFrame(rows)
    events.to_csv(DATA_DIR / "campaign_events.csv", index=False)

    # Survey is synthetic and stratified. Survey outcome includes a direct exposure effect.
    sampled = RNG.choice(user_id, size=2400, replace=False)
    user_frame = events.query("period == 'post'").set_index("user_id").loc[sampled].reset_index()
    awareness_prob = sigmoid(
        -0.4
        + 0.58 * user_frame["exposed"].to_numpy()
        + 0.36 * user_frame["prior_brand_awareness"].to_numpy()
        + 0.12 * user_frame["pre_engagement"].to_numpy()
    )
    consideration_prob = sigmoid(
        -0.78
        + 0.34 * user_frame["exposed"].to_numpy()
        + 0.40 * user_frame["prior_brand_awareness"].to_numpy()
        + 0.08 * user_frame["pre_engagement"].to_numpy()
    )
    survey = user_frame[["user_id", "exposed", "audience_segment", "region"]].copy()
    survey["brand_awareness"] = RNG.binomial(1, awareness_prob)
    survey["brand_consideration"] = RNG.binomial(1, consideration_prob)
    survey["survey_weight"] = np.where(survey["region"].eq("US"), 0.95, 1.15)
    survey.to_csv(DATA_DIR / "brand_lift_survey.csv", index=False)

    print(f"Wrote {len(events):,} event rows and {len(survey):,} survey rows to {DATA_DIR}")


if __name__ == "__main__":
    main()
